﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ToDoApp.Interfaces
{
    public interface ISearchPage
    {
        void OnSearchBarTextChanged(string text);
    }
}
